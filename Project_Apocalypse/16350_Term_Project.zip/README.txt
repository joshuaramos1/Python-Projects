



Hi! Thank you for taking interest in our Apocalyptic Simulator! If you would like
to try our simulator, please follow the steps below:

python .\run.py

 - To Run multiple trials, modify the num_trials variable

 - To modify the environment, at the top of planner.py, you can modify:
      NUMOBS: number of randomly generated obstacles
      NUMZ: number of randomly generated zombies
      MAPSz: size of map
      NUMSs: number of randomly generated searchers
      NUMLs: number of randomly generated lost people

- To modify the frame rate of our simulation, at the top of simulation.py you
  can modify FRAME_RATE to modify the animation's frame rate (speed up or 
  slow down)

- To modify our LRTA* step horizon, modify N_STEPS

- To modify the Zombie-Planner's execution time, modify ZOMBIE_MOVE_TIME



Once again, thank you so much for taking interest in our project. Enjoy!

















